/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Currency_Exchange;

/**
 *
 * @author snipi
 */
public class Node {
    // Variables for a node in a graph
    String name;
    int x;
    int y;
    
    // Constructor for initializing the variables of a node
    public Node(String name, int x, int y) {
        this.name = name;
        this.x = x;
        this.y = y;
    }
}
