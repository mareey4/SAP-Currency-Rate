/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Currency_Exchange;

/**
 *
 * @author snipi
 */
public class Shapes {
    // Variables for drawing the nodes of a graph
    int size;
    Node[] nodes;
    Node[] labels;
    
    // Parent constructor for initializing the variables of a graph
    public Shapes(int size) {
        this.size = size;
        this.nodes = new Node[this.size];
        this.labels = new Node[((this.size - 1) * this.size)];
    }
}
